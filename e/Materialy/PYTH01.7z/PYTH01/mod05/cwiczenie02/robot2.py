pozycja = 0
mnoznik = {'E': 1, 'S': -1j, 'W': -1, 'N': 1j}
while True:
    command = input('Wydaj polecenie: ')
    if not command:
        break
    kierunek, krok = command.split(' ')
    krok = int(krok)
    if kierunek in mnoznik.keys():
        pozycja += mnoznik[kierunek]*krok
    x, y = pozycja.real, pozycja.imag
    print(f'Bieżące położenie: ({x}, {y})')
print('Odległość od punktu startu {}'.format(abs(pozycja)))
