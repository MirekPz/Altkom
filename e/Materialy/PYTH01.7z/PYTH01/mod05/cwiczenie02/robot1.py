import math

x = y = 0  # współrzędne początkowe
while True:
    command = input('Wydaj polecenie: ')
    if not command:
        break
    kierunek, krok = command.split()
    krok = int(krok)
    if kierunek == "E":
        x += krok
    elif kierunek == "S":
        y -= krok
    elif kierunek == "W":
        x -= krok
    elif kierunek == "N":
        y += krok
    else:
        continue
    print('Bieżące położenie: ({}, {})'.format(x, y))

print('Odległość od punktu startu {}'.format(math.hypot(x, y)))
