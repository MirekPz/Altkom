# argumenty są wstawiane w podanej kolejności
print('[{} {}]'.format('abc', 'xyz'))

# można wskazać pozycję argumentu
print('[{0} {1}]'.format('abc', 'xyz'))
print('[{1} {0}]'.format('abc', 'xyz'))

# do tego samego argumentu można się odwołać wielokrotnie
print('[{0} {0}]'.format('abc'))


# FORMATOWANIE TEKSTU

print('\nFORMATOWANIE TEKSTU:')
# min. szerokość argumentu i justowanie
print('[{:10}]'.format('abc'))  # dosunięcie do lewej
print('[{:>10}]'.format('abc'))  # dosunięcie do prawej
print('[{:^10}]'.format('abc'))  # wyśrodkowanie (ew. nadmiarowy znak jest umieszczany z prawej strony)

# znaki uzupełnienia
print('[{:_<10}]'.format('abc'))

# przycięcie
print('[{:.2}]'.format('abc'))
print('[{:10.2}]'.format('abc'))


# FORMATOWANIE LICZB

print('\nFORMATOWANIE LICZB:')

# liczby całkowite
print('[{:d}]'.format(123))
print('[{:6d}]'.format(123))
print('[{:06d}]'.format(123))
print('[{:06d}]'.format(-123))
print('[{:+d}]'.format(123))  # obowiązkowo znak (minus lub plus)
print('[{: d}]'.format(123))  # obowiązkowo znak (minus lub spacja)
print('[{:=6d}]'.format(-123))  # znak na początku
print('[{:=+6d}]'.format(123))  # obowiązkowo znak na początku

# liczby zmiennoprzecinkowe
print('[{:f}]'.format(12.3456))
print('[{:12f}]'.format(12.3456))
print('[{:12.2f}]'.format(12.3456))


# FORMATOWANIE DATY

print('\nFORMATOWANIE DATY:')

from datetime import date
print('{:%Y-%m-%d}'.format(date.today()))


# PARAMETRY

print('\nUŻYCIE PARAMETRÓW:')

# użycie parametrów nazwanych
print('[{imie} {nazwisko}]'.format(imie='Jan', nazwisko='Kowalski'))

# można sparametryzować także szerokość i precyzję
print('[{:{align}{prec}}]'.format('abcd', align='^', prec=10))
