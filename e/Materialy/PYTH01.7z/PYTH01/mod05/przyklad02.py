# zarządzanie wielkością liter
print('Jan Kowalski junior'.capitalize())
print('Jan Kowalski junior'.lower())
print('Jan Kowalski junior'.upper())
print('Jan Kowalski junior'.swapcase())
print('Jan Kowalski junior'.title())

# pozycjonowanie tekstu
s = 'Python'.ljust(10); print('[' + s + ']')
s = 'Python'.ljust(10, '-'); print('[' + s + ']')

s = 'Python'.center(10); print('[' + s + ']')
s = 'Python'.center(10, '-'); print('[' + s + ']')

s = 'Python'.rjust(10); print('[' + s + ']')
s = 'Python'.rjust(10, '-'); print('[' + s + ']')

s = 'Python'.zfill(10); print('[' + s + ']')

# usuwanie znaków
s = 'tattoo'.lstrip('at'); print('[' + s + ']')  # znaki usuwane z początku do pierwszego niepasującego
s = 'tattoo'.strip('ot'); print('[' + s + ']')   # znaki usuwane z początku i końca do pierwszego niepasującego
s = 'tattoo'.rstrip('ot'); print('[' + s + ']')   # znaki usuwane z końca do pierwszego niepasującego

# wyszukiwanie tekstu
# zwracany jest najmniejszy indeks
# W razie nie znalezienia:
#   - find zwraca -1
#   - index rzuca wyjątkiem
print('blablabla'.find('la'))
print('blablabla'.find('la', 6))
print('blablabla'.find('la', 2, 5))

# zwracany jest największy indeks
print('blablabla'.rfind('bla'))
print('blablabla'.rfind('bla', 7))
print('blablabla'.rfind('bla', 2, 6))

# podział tekstu
print('to be or not to be'.split())
print('to be or not to be'.split(sep='be'))
print('to be or not to be'.split(maxsplit=2))
print('to be or not to be'.rsplit(maxsplit=2))

print('to be\nor\nnot to be'.splitlines())
print('to be\nor\nnot to be'.splitlines(True))

print('to be or not to be'.partition('be'))
print('to be or not to be'.rpartition('be'))

print('ananas'.replace('nana', 'loe'))

translation = str.maketrans('dmS', 'mrG')
print('Sodoma'.translate(translation))

print('_'.join('Python'))

