"""
Skrypt tworzy skrót na podstawie pierwszych dużych liter słów.

Przykładowo dla:
    United Nations Educational, Scientific and Cultural Organization --> UNESCO
"""

# dane wejściowe
full_name = 'United Nations Educational, Scientific and Cultural Organization'

# budowa skrótu
short_name = ''   # zmienna zawierająca skrót
for word in full_name.split():
    first_character = word[0]
    if first_character.isupper():
        short_name += first_character

# wypisanie oryginalnej nazwy i jej skrótu
print(full_name, '=', short_name)
