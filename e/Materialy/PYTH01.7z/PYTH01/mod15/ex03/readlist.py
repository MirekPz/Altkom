from mod14.ex01.person import Person
from mod14.ex01.address import Address

print('początek deserializacji...')
with open('people.txt', 'r', encoding='utf-8') as source:
    lista = list(map(lambda s: eval(s), source))
print('gotowe...')

print(*lista, sep='\n')
