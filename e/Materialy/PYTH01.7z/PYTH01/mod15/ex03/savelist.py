from mod14.ex01.people4 import osoby

print('początek serializacji...')
with open('people.txt', 'w', encoding='utf-8') as output:
    for osoba in osoby:
        output.write(f'{osoba!r}\n')  # konwersja osoba -> repr(osoba)

print('gotowe...')
