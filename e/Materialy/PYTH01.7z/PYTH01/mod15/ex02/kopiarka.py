with open('wiersz1.txt', 'w', encoding='utf-8') as output:
    for input_filename in ('czesc1.txt', 'czesc2.txt'):
        with open(input_filename, 'r', encoding='utf-8') as source:
            output.write(source.read())
            output.write('\n')
