for filename in ('czesc1.txt', 'czesc2.txt'):
    with open(filename, 'r', encoding='utf-8') as f:
        # f jest iterowalne, odczyt linia po linii
        for line in f:
            print(line.strip())
        # zamiast pętli można też jak poniżej, ale wtedy wczytujemy wszystko na raz
        # print(f.read())
