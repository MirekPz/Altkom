with open('czesc1.txt', 'r', encoding='utf-8') as in1, open('czesc2.txt', 'r', encoding='utf-8') as in2:
    for line1, line2 in zip(in1, in2):
        print(line1.strip())
        print(line2.strip())
