class Address:
    def __init__(self, street, zipcode, city):
        self.street = street
        self.zipcode = zipcode
        self.city = city

    def __str__(self):
        return f'{self.street}, {self.zipcode} {self.city}'

    def __repr__(self):
        # return "{}('{}', '{}', '{}')".format(self.__class__.__name__, self.street, self.zipcode, self.city)
        return f'{self.__class__.__name__}("{self.street}", "{self.zipcode}", "{self.city}")'


if __name__ == '__main__':
    # test klasy
    # powinien być wykonany tylko z tego modułu (nie powinien być importowany)

    a = Address('ul. Bracka 1', '12-345', 'Kraków')
    print(str(a))
    print(repr(a))
