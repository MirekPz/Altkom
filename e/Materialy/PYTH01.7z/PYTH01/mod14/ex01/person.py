class Person:
    def __init__(self, fname, lname, address):
        self.fname = fname
        self.lname = lname
        self.address = address

    def __str__(self):
        return f'{self.fname} {self.lname}, zam.: {self.address}'

    def __repr__(self):
        return "{}('{}', '{}', {!r})".format(self.__class__.__name__, self.fname, self.lname, self.address)
