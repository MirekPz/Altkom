import mod14.ex01.person as p, mod14.ex01.address

osoby = [p.Person('Jan', 'Kowalski', mod14.ex01.address.Address('ul. Morska 11', '12-345', 'Gdańsk')),
         p.Person('Adam', 'Bednarek', mod14.ex01.address.Address('ul. Polna 3', '23-456', 'Mrągowo')),
         p.Person('Anna', 'Jabłońska', mod14.ex01.address.Address('ul. Polska 42', '34-567', 'Kołobrzeg'))]

print(*osoby, sep='\n')
