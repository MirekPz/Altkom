from mod14.ex01 import person, address as a

osoby = [person.Person('Jan', 'Kowalski', a.Address('ul. Morska 11', '12-345', 'Gdańsk')),
         person.Person('Adam', 'Bednarek', a.Address('ul. Polna 3', '23-456', 'Mrągowo')),
         person.Person('Anna', 'Jabłońska', a.Address('ul. Polska 42', '34-567', 'Kołobrzeg'))]

print(*osoby, sep='\n')
