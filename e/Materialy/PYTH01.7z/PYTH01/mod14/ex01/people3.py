from mod14.ex01 import *
# trzeba zdefiniować atrybut __all__

osoby = [person.Person('Jan', 'Kowalski', address.Address('ul. Morska 11', '12-345', 'Gdańsk')),
         person.Person('Adam', 'Bednarek', address.Address('ul. Polna 3', '23-456', 'Mrągowo')),
         person.Person('Anna', 'Jabłońska', address.Address('ul. Polska 42', '34-567', 'Kołobrzeg'))]

print(*osoby, sep='\n')
