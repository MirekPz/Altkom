from mod14.ex01.person import Person
from mod14.ex01.address import *

osoby = [Person('Jan', 'Kowalski', Address('ul. Morska 11', '12-345', 'Gdańsk')),
         Person('Adam', 'Bednarek', Address('ul. Polna 3', '23-456', 'Mrągowo')),
         Person('Anna', 'Jabłońska', Address('ul. Polska 42', '34-567', 'Kołobrzeg'))]


print(*osoby, sep='\n')
