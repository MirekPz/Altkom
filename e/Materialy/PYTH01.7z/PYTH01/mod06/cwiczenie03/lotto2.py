"""
Skrypt oblicza szansę zadanej liczby trafień w lotto.

Wyrażenie, które należy obliczyć to (p. ćwiczenie 3.3):
        silnia(n) / (silnia(n-k) * silnia(k))
gdzie:
    n - pula liczb z której losujemy
    k - ilość losowanych liczb

W rozwiązaniu do wyliczenia silni użyte zostały pętle
"""


# wczytanie danych wejściowych
k = int(input('Ile liczb będziesz losował? '))
n = int(input('Spośród ilu liczb? '))

# wyliczenie wyrażenia:
#    silnia(k) = 1 * 2 * ... * k
mianownik_wyrazenia = 1
for liczba in range(1, k + 1):
    mianownik_wyrazenia *= liczba

# wyliczenie wyrażenia:
#    silnia(n) / silnia(n - k) = (n - k + 1) * (n - k + 2) * ... * (n -1) * n
licznik_wyrazenia = 1
for liczba in range(n - k + 1, n + 1):
    licznik_wyrazenia *= liczba

# wyliczenie liczby kombinacji:
liczba_kombinacji = licznik_wyrazenia // mianownik_wyrazenia

# wypisanie wyniku
print('Szansa na trafienie {} liczb z {} wynosi 1 : {:,}'.format(k, n, liczba_kombinacji))
