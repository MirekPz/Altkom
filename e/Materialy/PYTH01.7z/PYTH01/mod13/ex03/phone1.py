class PrepaidPhone:
    """
    Klasa symuluje działanie telefonu na kartę.

    atrybut __limit: przechowuje aktualny stan minut do wykorzystania
    """
    def __init__(self, starter):  # symulacja startera
        self.__limit = starter

    def get_limit(self):  # odczyt bieżącego stanu konta (ilości minut do wykorzystania)
        return self.__limit

    def add_to_limit(self, top_up):  # doładowanie konta
        self.__limit += top_up

    def call(self, time):  # rozmowa
        print('Nice call...')
        self.__limit -= time


# Test działania klasy
phone = PrepaidPhone(10)  # starter
for i in range(11):
    phone.call(7)  # rozmowa

    # Doładowujemy konto mniejszą liczbą minut niż trwa rozmowa,
    # co może doprowadzić do braku środków, czyli sytuacji wyjątkowej.
    # Program nie jest na to przygotowany i zapewne doprowadzi
    # do ujemnego stanu konta... (będzie działał, tak jakby nic się nie stało)
    phone.add_to_limit(5)  # doładowanie

    print('{} min left for calls...'.format(phone.get_limit()))  # ile minut pozostało?
