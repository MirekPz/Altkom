class PrepaidPhoneError(Exception):
    """
    Nasz własny wyjątek sygnalizujący brak wystarczającej liczby minut na koncie na rozmowę.
    """
    def __init__(self, time_left):
        super().__init__(f'PROBLEM: Current call exceeds limit of {time_left} min.')


class PrepaidPhone:
    def __init__(self, starter):
        self.__limit = starter

    def get_limit(self):
        return self.__limit

    def add_to_limit(self, top_up):
        self.__limit += top_up

    def call(self, time):
        if self.__limit < time:
            raise PrepaidPhoneError(self.__limit)
        print('Nice call...')
        self.__limit -= time


phone = PrepaidPhone(10)
for i in range(11):
    try:
        phone.call(7)
    except PrepaidPhoneError as e:
        print(e)
        phone.add_to_limit(5)
        print('Topping up. Current limit:', phone.get_limit(), "min")
    else:
        print('{} min left for calls...'.format(phone.get_limit()))
