"""
Skrypt tworzy listę słowników opisujących osoby, a następnie wykonuje operacje na tych danych.
"""

# funkcja z podanej sekwencji pozostawia tylko te elementy, które spełniają podany predykat
def sito(predykat, sekwencja):
    return [element for element in sekwencja if predykat(element)]


# funkcja przekształca wszystkie elementy sekwencji wykonując na każdym podaną funkcję
def transformacja(funkcja, sekwencja):
    return [funkcja(element) for element in sekwencja]


# Dane wejściowe
osoba1 = {
    'imie': 'Jan',
    'nazwisko': 'Kowalski',
    'adres': 'Warszawa',
    'plec': True,
    'wiek': 22
}
osoba2 = {
    'imie': 'Anna',
    'nazwisko': 'Jabłońska',
    'adres': 'Poznań',
    'plec': False,
    'wiek': 18
}
osoba3 = {
    'imie': 'Tomasz',
    'nazwisko': 'Nowak',
    'adres': 'Wrocław',
    'plec': True,
    'wiek': 30
}
osoba4 = {
    'imie': 'Alicja',
    'nazwisko': 'Młynarska',
    'adres': 'Warszawa',
    'plec': False,
    'wiek': 25
}

lista_osob = [osoba1, osoba2, osoba3, osoba4]


# lista mężczyzn mieszkających w Warszawie
def predykat_warszawiakow(osoba):
    return osoba['plec'] and osoba['adres'] == 'Warszawa'


warszawiacy = sito(predykat_warszawiakow, lista_osob)
print('Lista warszawiaków:', *warszawiacy, sep='\n', end='\n\n')


# lista dwudziestolatków
def predykat_wieku(osoba):
    return 20 <= osoba['wiek'] < 30


dwudziestoletni = sito(predykat_wieku, lista_osob)
print('Lista dwudziestolatków i dwudziestolatek:', *dwudziestoletni, sep='\n', end='\n\n')


# średnia wieku kobiet o imionach rozpoczynających się na 'A'
def predykat_kobiet_o_imieniu_na_a(osoba):
    return not osoba['plec'] and osoba['imie'].startswith('A')
#    return not osoba['plec'] and osoba['imie'][0]=='A'


def funkcja_konwersji_na_wiek(osoba):
    return osoba['wiek']


lista_kobiet_na_A = sito(predykat_kobiet_o_imieniu_na_a, lista_osob)
lista_lat = transformacja(funkcja_konwersji_na_wiek, lista_kobiet_na_A)
srednia_wieku = sum(lista_lat) / len(lista_lat)
print('Średnia wieku kobiet o imionach na A...:', srednia_wieku)
