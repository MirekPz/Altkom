"""
Skrypt tworzy listę słowników opisujących osoby, a następnie wykonuje operacje na tych danych.
"""

# Dane wejściowe
osoba1 = {
    'imie': 'Jan',
    'nazwisko': 'Kowalski',
    'adres': 'Warszawa',
    'plec': True,
    'wiek': 22
}
osoba2 = {
    'imie': 'Anna',
    'nazwisko': 'Jabłońska',
    'adres': 'Poznań',
    'plec': False,
    'wiek': 18
}
osoba3 = {
    'imie': 'Tomasz',
    'nazwisko': 'Nowak',
    'adres': 'Wrocław',
    'plec': True,
    'wiek': 30
}
osoba4 = {
    'imie': 'Alicja',
    'nazwisko': 'Młynarska',
    'adres': 'Warszawa',
    'plec': False,
    'wiek': 25
}

lista_osob = [osoba1, osoba2, osoba3, osoba4]
print(*lista_osob, sep='\n')

# sortowanie wg nazwisk
lista_osob_wg_nazwisk = sorted(lista_osob, key=lambda o: o['nazwisko'])
print('\nLista osób posortowana wg nazwisk:')
print(*lista_osob_wg_nazwisk, sep='\n')

# sortowanie wg płci i wieku
lista_osob_wg_plci_i_wieku = sorted(lista_osob, key=lambda o: (o['plec'], o['wiek']))
print('\nLista osób posortowana wg płci i wieku:')
print(*lista_osob_wg_plci_i_wieku, sep='\n')
