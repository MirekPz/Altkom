"""
skryt tworzy dwuwymiarową macierz jednostkową
"""

wymiar = 4
macierz = [[1 if wiersz == kolumna else 0 for kolumna in range(wymiar)] for wiersz in range(wymiar)]
print(macierz)
