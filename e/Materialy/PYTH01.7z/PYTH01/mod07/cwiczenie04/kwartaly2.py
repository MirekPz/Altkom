"""
skrypt przekształca listę miesięcy w nową listę w której miesiące są pogrupowane w kwartały
"""

# lista nazw miesięcy
rok = ['styczeń', 'luty', 'marzec', 'kwiecień', 'maj', 'czerwiec',
       'lipiec', 'sierpień', 'wrzesień', 'październik', 'listopad', 'grudzień']

dlugosc_kwartalu = len(rok) // 4

# lista kwartałów
# każdy kwartał jest listą 3 miesięcy
kwartaly = [[miesiac for nr_miesiaca, miesiac in enumerate(rok) if nr_miesiaca // dlugosc_kwartalu == numer_kwartalu]
            for numer_kwartalu in range(4)]
# kwartaly = [[rok[i + numer_kwartalu * dlugosc_kwartalu] for i in range(dlugosc_kwartalu)]
#             for numer_kwartalu in range(4)]

# wypisanie listy kwartałów
print('Kwartały:')
print(kwartaly, end='\n\n')

# wypisanie listy kwartałów, każdy kwartał w osobnej linii
print(*kwartaly, sep='\n')
