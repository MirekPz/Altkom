"""
Skrypt z listy nazw miesięcy wypisuje te, które są początkami kwartałów.
"""

# lista miesięcy
rok = ['styczeń', 'luty', 'marzec', 'kwiecień', 'maj', 'czerwiec',
       'lipiec', 'sierpień', 'wrzesień', 'październik', 'listopad', 'grudzień']

dlugosc_kwartalu = len(rok) // 4

# lista zawierająca nazwa miesięcy rozpoczynających kwartały
poczatki_kwartalow = [miesiac for nr, miesiac in enumerate(rok) if nr % dlugosc_kwartalu == 0]

# wypisanie elementów listy
print('Początki kwartałów:')
print(*poczatki_kwartalow, sep=', ', end='\n\n')

# to samo, ale prościej...
print('Początki kwartałów:')
print(*rok[::3], sep=', ')
