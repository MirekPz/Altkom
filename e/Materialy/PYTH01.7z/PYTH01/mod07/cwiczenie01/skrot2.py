"""
skrypt tworzy skrót na podstawie pierwszych dużych liter słów
np. dla:
United Nations Educational, Scientific and Cultural Organization --> UNESCO
"""

# dane wejściowe
fullname = 'United Nations Educational, Scientific and Cultural Organization'

# budowa skrótu
shortname = ''.join([word[0] for word in fullname.split() if word[0].isupper()])

# wypisanie oryginalnej nazwy i jej skrótu
print(fullname, '=', shortname)
