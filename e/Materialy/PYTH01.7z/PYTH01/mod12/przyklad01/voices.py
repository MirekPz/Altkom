"""
Prezentacja dziedziczenia metod i polimorfizmu.
"""

class Zwierze:
    def daj_glos(self):
        return 'nie odzywam się'

    def __str__(self):
        return f'{self.__class__.__name__:5} --> {self.daj_glos()}'


class Pies(Zwierze):
    def daj_glos(self):
        return "hau hau"


class Kot(Zwierze):
    def daj_glos(self):
        return "miau miau"


class Ryba(Zwierze):
    pass


for zwierze in [Pies(), Kot(), Ryba()]:
    print(zwierze)
